<?php

class Brizy_Editor_Exceptions_DataVersionMismatch extends Exception {
}