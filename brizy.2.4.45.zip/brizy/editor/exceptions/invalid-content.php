<?php

class Brizy_Editor_Exceptions_InvalidContent extends Brizy_Editor_Exceptions_Exception {
	protected $message = 'Content is invalid';
}