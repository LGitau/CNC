<?php

class Brizy_Editor_Http_Exceptions_BadRequest extends Brizy_Editor_Http_Exceptions_ResponseException {

}