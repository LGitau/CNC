<?php

interface Brizy_Editor_Data_ProjectMergeStrategyInterface {
	public function merge( $projectData1, $projectData2 );
}